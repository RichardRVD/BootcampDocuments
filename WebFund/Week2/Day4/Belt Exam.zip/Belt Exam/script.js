function removeBanner(){
    var cookie = document.getElementById('cookieBanner');
    cookie.remove();
}
function over(){
    var img = document.getElementById('succimg');
    img.src = "succulents-2.jpg"
}
function replace(){
    var img = document.getElementById('succimg');
    img.src = "succulents-1.jpg"
}