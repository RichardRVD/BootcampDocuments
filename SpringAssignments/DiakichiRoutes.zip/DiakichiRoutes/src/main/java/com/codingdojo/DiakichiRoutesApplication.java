package com.codingdojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiakichiRoutesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiakichiRoutesApplication.class, args);
	}

}
